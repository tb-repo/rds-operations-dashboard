"use strict";
/**
 * AWS Lambda Handler for BFF Express Application
 *
 * This file wraps the Express app for Lambda execution using serverless-express.
 * The Lambda function handler is exported as 'handler'.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const serverless_express_1 = __importDefault(require("@vendia/serverless-express"));
const index_1 = __importDefault(require("./index"));
// Create Lambda handler by wrapping Express app
exports.handler = (0, serverless_express_1.default)({ app: index_1.default });
//# sourceMappingURL=lambda.js.map