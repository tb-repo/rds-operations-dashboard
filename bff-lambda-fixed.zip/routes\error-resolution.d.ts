/**
 * Error Resolution API Routes
 *
 * Provides BFF endpoints for the error resolution and monitoring system.
 * Integrates with the error resolution Lambda functions.
 *
 * Metadata:
 * {
 *   "generated_by": "claude-3.5-sonnet",
 *   "timestamp": "2025-12-16T14:30:00Z",
 *   "version": "1.0.0",
 *   "policy_version": "v1.0.0",
 *   "traceability": "REQ-6.1, 6.2 → DESIGN-Integration → TASK-7",
 *   "review_status": "Pending",
 *   "risk_level": "Level 2",
 *   "reviewed_by": null,
 *   "approved_by": null
 * }
 */
import { Router } from 'express';
export declare function createErrorResolutionRoutes(internalApiUrl: string, getApiKey: () => string): Router;
//# sourceMappingURL=error-resolution.d.ts.map