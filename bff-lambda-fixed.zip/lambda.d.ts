/**
 * AWS Lambda Handler for BFF Express Application
 *
 * This file wraps the Express app for Lambda execution using serverless-express.
 * The Lambda function handler is exported as 'handler'.
 */
export declare const handler: any;
//# sourceMappingURL=lambda.d.ts.map