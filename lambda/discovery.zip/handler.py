"""
RDS Discovery Service Lambda Handler

Purpose: Discover RDS instances across multiple AWS accounts and regions.
Assumes cross-account roles, queries RDS API, and extracts instance metadata.

Design Decisions:
- Parallel discovery across regions for performance
- Graceful failure handling (continue on per-account/region errors)
- Comprehensive metadata extraction for dashboard needs
- Tag-based environment classification

Governance Metadata:
{
  "generated_by": "claude-3.5-sonnet",
  "timestamp": "2025-12-02T00:00:00Z",
  "version": "1.0.0",
  "policy_version": "v1.0.0",
  "traceability": "REQ-1.1, REQ-1.2, REQ-9.1 → DESIGN-001 → TASK-2",
  "review_status": "Pending",
  "risk_level": "Level 2",
  "reviewed_by": null,
  "approved_by": null
}
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

# Import shared utilities
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from shared import AWSClients, Config, log_execution
from shared.structured_logger import get_logger
from shared.correlation_middleware import with_correlation_id, CorrelationContext
from persistence import persist_instances
from discovery import discover_all_instances

# Initialize logger
logger = get_logger(__name__)

# Monitoring functions - create stubs if they don't exist
def publish_discovery_metrics(discovery_results, persistence_results, config):
    """Publish metrics to CloudWatch."""
    pass

def send_discovery_notification(discovery_results, persistence_results, config):
    """Send SNS notification."""
    pass


@with_correlation_id
def lambda_handler(event, context):
    """
    Lambda handler for RDS instance discovery.
    
    Resilient Design:
    - Never fails the entire Lambda due to account/region errors
    - Always returns success (200) if at least one account/region succeeds
    - Only returns error (500) if catastrophic failure (e.g., DynamoDB unavailable)
    - Collects and reports all errors for troubleshooting
    
    Args:
        event: EventBridge scheduled event or manual invocation
        context: Lambda context
    
    Returns:
        dict: Discovery results summary (always returns 200 unless catastrophic failure)
    
    Requirements: REQ-1.1 (multi-account discovery), REQ-1.2 (metadata extraction), REQ-5.1 (structured logging)
    """
    # Initialize structured logger with correlation ID
    logger = get_logger('discovery-service', event=event, lambda_context=context)
    
    logger.info('Discovery service started')
    
    discovery_results = None
    persistence_results = None
    config = None
    
    try:
        # Load configuration (gracefully handle missing config)
        try:
            config = Config.load()
        except Exception as config_error:
            logger.warn('Could not load full configuration, using defaults',
                         error=str(config_error))
            # Create a minimal config object
            class MinimalConfig:
                pass
            config = MinimalConfig()
        
        # Discover instances across all accounts and regions
        # This function is designed to NEVER throw - it catches all errors internally
        discovery_results = discover_all_instances(config)
        
        # Check if we discovered ANY instances
        if discovery_results['total_instances'] == 0 and len(discovery_results['errors']) > 0:
            logger.warn('No instances discovered, but errors occurred',
                         error_count=len(discovery_results['errors']))
        
        # Persist discovered instances to DynamoDB (even if empty list)
        # Wrap in try-catch to ensure persistence failures don't fail the Lambda
        try:
            persistence_results = persist_instances(
                instances=discovery_results['instances'],
                config=config
            )
        except Exception as persist_error:
            logger.error('Persistence failed but continuing',
                        error_type=type(persist_error).__name__,
                        error_message=str(persist_error))
            persistence_results = {
                'success': False,
                'error': str(persist_error),
                'new_instances': 0,
                'updated_instances': 0,
                'deleted_instances': 0
            }
        
        # Publish metrics to CloudWatch (best effort)
        try:
            publish_discovery_metrics(discovery_results, persistence_results, config)
        except Exception as metrics_error:
            logger.warn('Failed to publish metrics',
                         error=str(metrics_error))
        
        # Send SNS notification if needed (best effort)
        try:
            send_discovery_notification(discovery_results, persistence_results, config)
        except Exception as sns_error:
            logger.warn('Failed to send SNS notification',
                         error=str(sns_error))
        
        # Combine results
        final_results = {
            **discovery_results,
            'persistence': persistence_results,
            'execution_status': 'completed_with_errors' if discovery_results['errors'] else 'completed_successfully'
        }
        
        # Determine overall success
        total_errors = len(discovery_results['errors']) + len(discovery_results.get('warnings', []))
        success_rate = 0
        if discovery_results['accounts_attempted'] > 0:
            success_rate = (discovery_results['accounts_scanned'] / discovery_results['accounts_attempted']) * 100
        
        # Log comprehensive summary
        logger.info('Discovery service completed',
                    total_instances=discovery_results['total_instances'],
                    accounts_attempted=discovery_results['accounts_attempted'],
                    accounts_scanned=discovery_results['accounts_scanned'],
                    accounts_failed=discovery_results['accounts_attempted'] - discovery_results['accounts_scanned'],
                    success_rate=f"{success_rate:.1f}%",
                    regions_scanned=discovery_results['regions_scanned'],
                    new_instances=persistence_results.get('new_instances', 0),
                    updated_instances=persistence_results.get('updated_instances', 0),
                    deleted_instances=persistence_results.get('deleted_instances', 0),
                    errors=len(discovery_results['errors']),
                    warnings=len(discovery_results.get('warnings', [])))
        
        # ALWAYS return 200 if discovery ran (even with errors)
        # This ensures the Lambda is considered successful and doesn't trigger alarms
        return {
            'statusCode': 200,
            'body': json.dumps(final_results, default=str)
        }
        
    except Exception as e:
        # Only catastrophic failures reach here (e.g., out of memory, DynamoDB completely unavailable)
        logger.error('Discovery service encountered catastrophic failure',
                     error_type=type(e).__name__,
                     error_message=str(e))
        
        # Even in catastrophic failure, try to return partial results
        if discovery_results:
            return {
                'statusCode': 200,  # Still return 200 if we have partial results
                'body': json.dumps({
                    **discovery_results,
                    'persistence': persistence_results or {'success': False, 'error': 'Not attempted'},
                    'execution_status': 'completed_with_catastrophic_error',
                    'catastrophic_error': {
                        'type': type(e).__name__,
                        'message': str(e)
                    }
                }, default=str)
            }
        
        # Only return 500 if we have absolutely nothing
        return {
            'statusCode': 500,
            'body': json.dumps({
                'execution_status': 'failed',
                'error': {
                    'type': type(e).__name__,
                    'message': str(e)
                },
                'total_instances': 0,
                'accounts_scanned': 0,
                'errors': []
            })
        }


@log_execution(logger)
def discover_all_instances(config: Any) -> Dict[str, Any]:
    """
    Intelligently discover RDS instances across current and configured accounts/regions.
    
    RESILIENCE GUARANTEE:
    - This function NEVER throws exceptions - it catches and logs all errors
    - Account failures are isolated - one failing account doesn't impact others
    - Region failures are isolated - one failing region doesn't impact others
    - Always returns a valid result dict, even if all accounts/regions fail
    
    Features:
    - Graceful failure handling - continues even if some accounts/regions fail
    - Detailed error reporting with actionable remediation steps
    - Automatic detection of enabled regions
    - Smart cross-account role validation
    
    Args:
        config: Application configuration
    
    Returns:
        dict: Discovery results with instances, errors, and remediation guidance
              NEVER returns None or throws exceptions
    
    Requirements: REQ-1.1 (multi-account, multi-region discovery)
    """
    all_instances = []
    errors = []
    warnings = []
    accounts_scanned = 0
    regions_scanned = 0
    current_account = None
    target_accounts = []
    target_regions = []
    cross_account_enabled = False
    
    try:
        # Get current account (wrapped in try-catch for resilience)
        try:
            import boto3
            sts = boto3.client('sts')
            current_account = sts.get_caller_identity()['Account']
            target_accounts = [current_account]  # Always include current account
        except Exception as e:
            logger.error('Failed to get current account identity',
                        error_type=type(e).__name__,
                        error_message=str(e))
            errors.append({
                'type': 'identity_failure',
                'severity': 'critical',
                'error': f'Cannot determine current AWS account: {str(e)}',
                'remediation': 'Check Lambda execution role has sts:GetCallerIdentity permission',
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            })
            # Return early if we can't even get current account
            return {
                'total_instances': 0,
                'instances': [],
                'accounts_scanned': 0,
                'accounts_attempted': 0,
                'regions_scanned': 0,
                'errors': errors,
                'warnings': warnings,
                'discovery_timestamp': datetime.utcnow().isoformat() + 'Z',
                'cross_account_enabled': False
            }
        
        # Check if cross-account discovery is configured (wrapped for resilience)
        try:
            if hasattr(config, 'cross_account') and config.cross_account.target_accounts:
                additional_accounts = [acc for acc in config.cross_account.target_accounts if acc != current_account]
                if additional_accounts:
                    cross_account_enabled = True
                    target_accounts.extend(additional_accounts)
                    logger.info('Cross-account discovery enabled',
                               additional_accounts=len(additional_accounts))
        except Exception as e:
            warnings.append({
                'type': 'cross_account_config',
                'severity': 'low',
                'message': 'Cross-account discovery not configured',
                'details': str(e),
                'remediation': 'To enable cross-account discovery, configure TARGET_ACCOUNTS environment variable',
                'impact': 'Discovery limited to current account only'
            })
            logger.info('Cross-account discovery not configured, using current account only')
        
        # Get enabled regions intelligently (wrapped for resilience)
        try:
            target_regions = get_enabled_regions()
        except Exception as e:
            logger.error('Failed to get enabled regions, using fallback',
                        error=str(e))
            target_regions = ['ap-southeast-1']  # Fallback to at least one region
            warnings.append({
                'type': 'region_detection_failed',
                'severity': 'medium',
                'message': 'Could not detect enabled regions, using fallback',
                'details': str(e),
                'remediation': 'Set TARGET_REGIONS environment variable explicitly',
                'impact': 'Discovery limited to fallback regions only'
            })
        
        logger.info('Starting intelligent discovery',
                    current_account=current_account,
                    total_accounts=len(target_accounts),
                    total_regions=len(target_regions),
                    cross_account_enabled=cross_account_enabled)
        
        # Discover instances for each account
        # Each account is completely isolated - failures don't propagate
        for account_id in target_accounts:
            is_current_account = (account_id == current_account)
            
            try:
                logger.info(f'Discovering instances in account: {account_id}',
                           account_id=account_id,
                           is_current_account=is_current_account)
                
                # Validate cross-account access before attempting discovery
                if not is_current_account:
                    try:
                        validation_result = validate_cross_account_access(account_id, config)
                        if not validation_result['accessible']:
                            errors.append({
                                'account_id': account_id,
                                'type': 'cross_account_access',
                                'severity': 'high',
                                'error': validation_result['error'],
                                'remediation': validation_result['remediation'],
                                'timestamp': datetime.utcnow().isoformat() + 'Z'
                            })
                            logger.warn(f'Skipping account due to access issues',
                                         account_id=account_id,
                                         reason=validation_result['error'])
                            continue
                    except Exception as validation_error:
                        logger.error('Cross-account validation failed',
                                   account_id=account_id,
                                   error=str(validation_error))
                        errors.append({
                            'account_id': account_id,
                            'type': 'validation_error',
                            'severity': 'high',
                            'error': f'Failed to validate cross-account access: {str(validation_error)}',
                            'remediation': 'Check cross-account role configuration and permissions',
                            'timestamp': datetime.utcnow().isoformat() + 'Z'
                        })
                        continue
                
                # Discover across all regions for this account
                # This function also never throws - it catches all errors internally
                account_instances, account_errors = discover_account_instances(
                    account_id=account_id,
                    regions=target_regions,
                    config=config,
                    is_current_account=is_current_account
                )
                
                all_instances.extend(account_instances)
                errors.extend(account_errors)
                accounts_scanned += 1
                regions_scanned += len(target_regions)
                
                logger.info(f'Account discovery completed',
                           account_id=account_id,
                           instances_found=len(account_instances),
                           errors=len(account_errors))
                
            except Exception as e:
                # This catch block should rarely be reached since discover_account_instances
                # handles its own errors, but we include it for absolute resilience
                error_msg = f'Unexpected error discovering account {account_id}: {str(e)}'
                logger.error(error_msg,
                            account_id=account_id,
                            error_type=type(e).__name__)
                
                # Provide intelligent error analysis
                try:
                    error_details = analyze_discovery_error(e, account_id, is_current_account)
                    errors.append(error_details)
                except Exception as analysis_error:
                    # Even error analysis failed - create basic error entry
                    logger.error('Error analysis failed',
                               error=str(analysis_error))
                    errors.append({
                        'account_id': account_id,
                        'type': 'unknown',
                        'severity': 'high',
                        'error': str(e),
                        'remediation': 'Check CloudWatch logs for detailed error information',
                        'timestamp': datetime.utcnow().isoformat() + 'Z'
                    })
    
    except Exception as outer_error:
        # Absolute last resort - something went wrong in the outer try block
        logger.error('Catastrophic error in discover_all_instances',
                    error_type=type(outer_error).__name__,
                    error_message=str(outer_error))
        errors.append({
            'type': 'catastrophic_failure',
            'severity': 'critical',
            'error': f'Discovery process encountered catastrophic error: {str(outer_error)}',
            'remediation': 'Contact support and review CloudWatch logs',
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        })
    
    # ALWAYS return a valid result, even if everything failed
    return {
        'total_instances': len(all_instances),
        'instances': all_instances,
        'accounts_scanned': accounts_scanned,
        'accounts_attempted': len(target_accounts),
        'regions_scanned': regions_scanned,
        'errors': errors,
        'warnings': warnings,
        'discovery_timestamp': datetime.utcnow().isoformat() + 'Z',
        'cross_account_enabled': cross_account_enabled
    }


def get_enabled_regions() -> List[str]:
    """
    Get list of enabled AWS regions for the account.
    Falls back to configured regions if unable to detect.
    
    Returns:
        list: Enabled region names
    """
    try:
        # Try to get enabled regions from environment first
        target_regions_str = os.environ.get('TARGET_REGIONS')
        if target_regions_str:
            return json.loads(target_regions_str)
        
        # Try to detect enabled regions
        import boto3
        ec2 = boto3.client('ec2', region_name='ap-southeast-1')
        response = ec2.describe_regions(
            Filters=[{'Name': 'opt-in-status', 'Values': ['opt-in-not-required', 'opted-in']}]
        )
        enabled_regions = [region['RegionName'] for region in response['Regions']]
        
        logger.info(f'Detected {len(enabled_regions)} enabled regions')
        return enabled_regions
        
    except Exception as e:
        logger.warn(f'Could not detect enabled regions, using defaults',
                      error=str(e))
        # Fallback to common regions
        return ['ap-southeast-1', 'us-east-1', 'eu-west-1']


def validate_cross_account_access(account_id: str, config: Any) -> Dict[str, Any]:
    """
    Validate that cross-account role exists and is accessible.
    
    Args:
        account_id: Target AWS account ID
        config: Application configuration
    
    Returns:
        dict: Validation result with accessibility status and remediation steps
    """
    try:
        # Check if cross-account configuration exists
        if not hasattr(config, 'cross_account'):
            return {
                'accessible': False,
                'error': 'Cross-account configuration not found',
                'remediation': 'Configure EXTERNAL_ID and CROSS_ACCOUNT_ROLE_NAME environment variables'
            }
        
        role_name = config.cross_account.role_name
        external_id = config.cross_account.external_id
        role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"
        
        # Try to assume the role
        sts = AWSClients.get_sts_client()
        sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName='rds-dashboard-validation',
            ExternalId=external_id,
            DurationSeconds=900
        )
        
        return {
            'accessible': True,
            'role_arn': role_arn
        }
        
    except Exception as e:
        error_str = str(e)
        
        # Provide specific remediation based on error type
        if 'AccessDenied' in error_str:
            remediation = f"""
            Cross-account role not accessible. To fix:
            1. Create IAM role '{role_name}' in account {account_id}
            2. Add trust policy allowing account {os.environ.get('AWS_ACCOUNT_ID', 'current')} to assume it
            3. Include ExternalId '{external_id}' in trust policy
            4. Attach policy with rds:Describe* permissions
            
            Example trust policy:
            {{
              "Version": "2012-10-17",
              "Statement": [{{
                "Effect": "Allow",
                "Principal": {{"AWS": "arn:aws:iam::{os.environ.get('AWS_ACCOUNT_ID', 'CURRENT_ACCOUNT')}:root"}},
                "Action": "sts:AssumeRole",
                "Condition": {{"StringEquals": {{"sts:ExternalId": "{external_id}"}}}}
              }}]
            }}
            """
        elif 'does not exist' in error_str:
            remediation = f"IAM role '{role_name}' does not exist in account {account_id}. Create the role first."
        else:
            remediation = f"Unable to access account {account_id}. Error: {error_str}"
        
        return {
            'accessible': False,
            'error': error_str,
            'remediation': remediation.strip()
        }


def analyze_discovery_error(error: Exception, account_id: str, is_current_account: bool) -> Dict[str, Any]:
    """
    Analyze discovery error and provide actionable remediation steps.
    
    Args:
        error: The exception that occurred
        account_id: AWS account ID where error occurred
        is_current_account: Whether this is the current account
    
    Returns:
        dict: Error details with remediation guidance
    """
    error_str = str(error)
    error_type = type(error).__name__
    
    # Determine error category and remediation
    if 'AccessDenied' in error_str or 'UnauthorizedOperation' in error_str:
        category = 'permissions'
        severity = 'high'
        if is_current_account:
            remediation = """
            Lambda execution role lacks RDS permissions. To fix:
            1. Go to IAM Console
            2. Find role 'RDSDashboardLambdaRole-prod'
            3. Attach policy with these permissions:
               - rds:DescribeDBInstances
               - rds:DescribeDBClusters
               - rds:ListTagsForResource
            """
        else:
            remediation = f"Cross-account role in account {account_id} lacks RDS permissions or trust relationship is incorrect"
    
    elif 'InvalidClientTokenId' in error_str or 'SignatureDoesNotMatch' in error_str:
        category = 'credentials'
        severity = 'critical'
        remediation = "AWS credentials are invalid or expired. Check Lambda execution role."
    
    elif 'Throttling' in error_str or 'RequestLimitExceeded' in error_str:
        category = 'rate_limit'
        severity = 'medium'
        remediation = "AWS API rate limit exceeded. Discovery will retry automatically on next run."
    
    elif 'Timeout' in error_str or 'timed out' in error_str:
        category = 'timeout'
        severity = 'medium'
        remediation = "Request timed out. This may be due to network issues or too many instances. Consider increasing Lambda timeout."
    
    elif 'Region' in error_str and 'not enabled' in error_str:
        category = 'region_disabled'
        severity = 'low'
        remediation = "Region is not enabled in this account. Enable the region in AWS Console or remove from TARGET_REGIONS."
    
    else:
        category = 'unknown'
        severity = 'medium'
        remediation = f"Unexpected error occurred. Review CloudWatch logs for details. Error type: {error_type}"
    
    return {
        'account_id': account_id,
        'type': category,
        'severity': severity,
        'error': error_str,
        'error_type': error_type,
        'remediation': remediation.strip(),
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'is_current_account': is_current_account
    }


def discover_account_instances(
    account_id: str,
    regions: List[str],
    config: Any,
    is_current_account: bool = True
) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Discover RDS instances in a single account across multiple regions.
    
    RESILIENCE GUARANTEE:
    - This function NEVER throws exceptions
    - Each region is completely isolated - failures don't propagate
    - Uses parallel execution for faster discovery
    - Always returns valid tuple (instances_list, errors_list)
    
    Args:
        account_id: AWS account ID
        regions: List of regions to scan
        config: Application configuration
        is_current_account: Whether this is the current account
    
    Returns:
        tuple: (instances, errors) - NEVER returns None or throws
    
    Requirements: REQ-1.1 (multi-region discovery)
    """
    instances = []
    errors = []
    
    try:
        # Use ThreadPoolExecutor for parallel region scanning
        with ThreadPoolExecutor(max_workers=4) as executor:
            # Submit discovery tasks for each region
            future_to_region = {}
            
            for region in regions:
                try:
                    future = executor.submit(
                        discover_region_instances,
                        account_id,
                        region,
                        config,
                        is_current_account
                    )
                    future_to_region[future] = region
                except Exception as submit_error:
                    # Failed to even submit the task
                    logger.error('Failed to submit region discovery task',
                               account_id=account_id,
                               region=region,
                               error=str(submit_error))
                    errors.append({
                        'account_id': account_id,
                        'region': region,
                        'type': 'task_submission_failed',
                        'severity': 'high',
                        'error': f'Failed to submit discovery task: {str(submit_error)}',
                        'remediation': 'Check Lambda memory and execution environment',
                        'timestamp': datetime.utcnow().isoformat() + 'Z'
                    })
            
            # Collect results as they complete
            for future in as_completed(future_to_region):
                region = future_to_region[future]
                try:
                    # Get result with timeout to prevent hanging
                    region_instances = future.result(timeout=60)
                    instances.extend(region_instances)
                    
                    logger.debug(f'Region discovery completed',
                                account_id=account_id,
                                region=region,
                                instances_found=len(region_instances))
                    
                except Exception as e:
                    # Region discovery failed - analyze and log, but continue
                    try:
                        error_details = analyze_region_error(e, account_id, region, is_current_account)
                        errors.append(error_details)
                    except Exception as analysis_error:
                        # Even error analysis failed - create basic error entry
                        logger.error('Region error analysis failed',
                                   account_id=account_id,
                                   region=region,
                                   error=str(analysis_error))
                        errors.append({
                            'account_id': account_id,
                            'region': region,
                            'type': 'discovery_failed',
                            'severity': 'medium',
                            'error': str(e),
                            'remediation': 'Check CloudWatch logs for detailed error information',
                            'timestamp': datetime.utcnow().isoformat() + 'Z'
                        })
                    
                    logger.warn(f'Region discovery failed but continuing',
                                account_id=account_id,
                                region=region,
                                error_type=type(e).__name__)
    
    except Exception as outer_error:
        # ThreadPoolExecutor itself failed - very rare
        logger.error('ThreadPoolExecutor failed',
                    account_id=account_id,
                    error_type=type(outer_error).__name__,
                    error_message=str(outer_error))
        errors.append({
            'account_id': account_id,
            'type': 'parallel_execution_failed',
            'severity': 'high',
            'error': f'Parallel region discovery failed: {str(outer_error)}',
            'remediation': 'Check Lambda memory and execution environment. Consider sequential discovery.',
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        })
    
    # ALWAYS return valid tuple, even if everything failed
    return instances, errors


def analyze_region_error(error: Exception, account_id: str, region: str, is_current_account: bool) -> Dict[str, Any]:
    """
    Analyze region-specific discovery error.
    
    Args:
        error: The exception that occurred
        account_id: AWS account ID
        region: AWS region
        is_current_account: Whether this is the current account
    
    Returns:
        dict: Error details with remediation
    """
    error_str = str(error)
    
    if 'not enabled' in error_str.lower() or 'not subscribed' in error_str.lower():
        return {
            'account_id': account_id,
            'region': region,
            'type': 'region_not_enabled',
            'severity': 'low',
            'error': f'Region {region} is not enabled',
            'remediation': f'Enable region {region} in AWS Console or remove from TARGET_REGIONS environment variable',
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }
    elif 'InvalidClientTokenId' in error_str:
        return {
            'account_id': account_id,
            'region': region,
            'type': 'invalid_credentials',
            'severity': 'high',
            'error': 'Invalid AWS credentials for this region',
            'remediation': 'Check cross-account role permissions and trust policy',
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }
    else:
        return {
            'account_id': account_id,
            'region': region,
            'type': 'discovery_failed',
            'severity': 'medium',
            'error': error_str,
            'remediation': f'Check CloudWatch logs for detailed error information. Error type: {type(error).__name__}',
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }


def discover_region_instances(
    account_id: str,
    region: str,
    config: Any,
    is_current_account: bool = True
) -> List[Dict[str, Any]]:
    """
    Discover RDS instances in a specific account and region.
    
    RESILIENCE GUARANTEE:
    - This function wraps all operations in try-catch
    - Individual instance extraction failures don't stop discovery
    - Returns empty list on complete failure (caller handles error logging)
    - Throws exception only to signal failure to caller (caught by caller)
    
    Args:
        account_id: AWS account ID
        region: AWS region
        config: Application configuration
        is_current_account: Whether this is the current account
    
    Returns:
        list: RDS instances with metadata (empty list if all fail)
    
    Raises:
        Exception: Only when region discovery completely fails (caught by caller)
    
    Requirements: REQ-1.2 (metadata extraction), REQ-9.1 (cross-account access)
    """
    instances = []
    
    try:
        # Get RDS client (with cross-account support if needed)
        if is_current_account:
            rds_client = AWSClients.get_rds_client(region=region)
        else:
            # Cross-account - assume role
            rds_client = AWSClients.get_rds_client(
                region=region,
                account_id=account_id,
                role_name=config.cross_account.role_name,
                external_id=config.cross_account.external_id
            )
        
        # Paginate through all DB instances
        paginator = rds_client.get_paginator('describe_db_instances')
        
        try:
            for page in paginator.paginate():
                for db_instance in page['DBInstances']:
                    try:
                        # Extract and normalize instance metadata
                        # Wrap each instance extraction to prevent one bad instance from failing all
                        instance_data = extract_instance_metadata(
                            db_instance=db_instance,
                            account_id=account_id,
                            region=region
                        )
                        instances.append(instance_data)
                    except Exception as extract_error:
                        # Log but continue - one bad instance shouldn't fail the whole region
                        instance_id = db_instance.get('DBInstanceIdentifier', 'unknown')
                        logger.warn('Failed to extract instance metadata, skipping instance',
                                     account_id=account_id,
                                     region=region,
                                     instance_id=instance_id,
                                     error=str(extract_error))
                        # Don't add to instances list, but don't fail the whole discovery
        
        except Exception as paginate_error:
            # Pagination failed - this is a region-level failure
            logger.error('Failed to paginate RDS instances',
                        account_id=account_id,
                        region=region,
                        error=str(paginate_error))
            # Re-raise to signal failure to caller
            raise
        
        logger.info('Region discovery successful',
                   account_id=account_id,
                   region=region,
                   instances_found=len(instances))
        
        return instances
    
    except Exception as e:
        # Region discovery failed completely
        logger.error('Region discovery failed',
                    account_id=account_id,
                    region=region,
                    error_type=type(e).__name__,
                    error_message=str(e))
        # Re-raise to signal failure to caller (who will log it properly)
        raise


def extract_instance_metadata(
    db_instance: Dict[str, Any],
    account_id: str,
    region: str
) -> Dict[str, Any]:
    """
    Extract and normalize RDS instance metadata.
    
    RESILIENCE:
    - Uses .get() with defaults for all optional fields
    - Handles missing or malformed data gracefully
    - Never throws on missing fields
    
    Args:
        db_instance: RDS DBInstance object from API
        account_id: AWS account ID
        region: AWS region
    
    Returns:
        dict: Normalized instance metadata
    
    Requirements: REQ-1.2 (comprehensive metadata extraction)
    """
    try:
        # Extract tags safely
        tags = {}
        try:
            if 'TagList' in db_instance:
                tags = {tag['Key']: tag['Value'] for tag in db_instance['TagList']}
        except Exception as tag_error:
            logger.warn('Failed to extract tags',
                         instance_id=db_instance.get('DBInstanceIdentifier', 'unknown'),
                         error=str(tag_error))
        
        # Determine environment from tags
        environment = tags.get('Environment', tags.get('environment', 'Unknown'))
        
        # Extract endpoint information safely
        endpoint = None
        port = None
        try:
            if 'Endpoint' in db_instance and db_instance['Endpoint']:
                endpoint = db_instance['Endpoint'].get('Address')
                port = db_instance['Endpoint'].get('Port')
        except Exception as endpoint_error:
            logger.warn('Failed to extract endpoint',
                         instance_id=db_instance.get('DBInstanceIdentifier', 'unknown'),
                         error=str(endpoint_error))
        
        # Extract VPC ID safely
        vpc_id = None
        try:
            if 'DBSubnetGroup' in db_instance and db_instance['DBSubnetGroup']:
                vpc_id = db_instance['DBSubnetGroup'].get('VpcId')
        except Exception as vpc_error:
            logger.warn('Failed to extract VPC ID',
                         instance_id=db_instance.get('DBInstanceIdentifier', 'unknown'),
                         error=str(vpc_error))
        
        # Extract latest restorable time safely
        latest_restorable_time = None
        try:
            if db_instance.get('LatestRestorableTime'):
                latest_restorable_time = db_instance['LatestRestorableTime'].isoformat()
        except Exception as time_error:
            logger.warn('Failed to extract latest restorable time',
                         instance_id=db_instance.get('DBInstanceIdentifier', 'unknown'),
                         error=str(time_error))
        
        # Build normalized instance data with safe defaults
        instance_data = {
            # Identifiers (required fields)
            'instance_id': db_instance.get('DBInstanceIdentifier', 'unknown'),
            'arn': db_instance.get('DBInstanceArn', f'arn:aws:rds:{region}:{account_id}:db:unknown'),
            'account_id': account_id,
            'region': region,
            
            # Engine information (required fields)
            'engine': db_instance.get('Engine', 'unknown'),
            'engine_version': db_instance.get('EngineVersion', 'unknown'),
            
            # Instance configuration
            'instance_class': db_instance.get('DBInstanceClass', 'unknown'),
            'storage_type': db_instance.get('StorageType', 'Unknown'),
            'allocated_storage': db_instance.get('AllocatedStorage', 0),
            'iops': db_instance.get('Iops'),
            'storage_encrypted': db_instance.get('StorageEncrypted', False),
            
            # Availability
            'multi_az': db_instance.get('MultiAZ', False),
            'availability_zone': db_instance.get('AvailabilityZone'),
            'status': db_instance.get('DBInstanceStatus', 'unknown'),
            
            # Network
            'endpoint': endpoint,
            'port': port,
            'publicly_accessible': db_instance.get('PubliclyAccessible', False),
            'vpc_id': vpc_id,
            
            # Backup configuration
            'backup_retention_period': db_instance.get('BackupRetentionPeriod', 0),
            'preferred_backup_window': db_instance.get('PreferredBackupWindow'),
            'latest_restorable_time': latest_restorable_time,
            
            # Maintenance
            'preferred_maintenance_window': db_instance.get('PreferredMaintenanceWindow'),
            'auto_minor_version_upgrade': db_instance.get('AutoMinorVersionUpgrade', False),
            'pending_modified_values': db_instance.get('PendingModifiedValues', {}),
            
            # Security
            'deletion_protection': db_instance.get('DeletionProtection', False),
            'iam_database_authentication_enabled': db_instance.get('IAMDatabaseAuthenticationEnabled', False),
            
            # Performance Insights
            'performance_insights_enabled': db_instance.get('PerformanceInsightsEnabled', False),
            
            # Tags and metadata
            'tags': tags,
            'environment': environment,
            
            # Discovery metadata
            'discovered_at': datetime.utcnow().isoformat() + 'Z',
            'last_updated': datetime.utcnow().isoformat() + 'Z'
        }
        
        return instance_data
    
    except Exception as e:
        # Absolute fallback - create minimal instance data
        logger.error('Failed to extract instance metadata, using minimal data',
                    instance_id=db_instance.get('DBInstanceIdentifier', 'unknown'),
                    error_type=type(e).__name__,
                    error_message=str(e))
        
        return {
            'instance_id': db_instance.get('DBInstanceIdentifier', 'unknown'),
            'arn': db_instance.get('DBInstanceArn', f'arn:aws:rds:{region}:{account_id}:db:unknown'),
            'account_id': account_id,
            'region': region,
            'engine': db_instance.get('Engine', 'unknown'),
            'engine_version': db_instance.get('EngineVersion', 'unknown'),
            'instance_class': db_instance.get('DBInstanceClass', 'unknown'),
            'status': db_instance.get('DBInstanceStatus', 'unknown'),
            'tags': {},
            'environment': 'Unknown',
            'discovered_at': datetime.utcnow().isoformat() + 'Z',
            'last_updated': datetime.utcnow().isoformat() + 'Z',
            'extraction_error': str(e)
        }


# For local testing
if __name__ == '__main__':
    # Mock Lambda context
    class MockContext:
        request_id = 'test-request-123'
        function_name = 'rds-discovery-test'
    
    # Set environment variables for testing
    os.environ['INVENTORY_TABLE'] = 'rds-inventory-test'
    os.environ['METRICS_CACHE_TABLE'] = 'metrics-cache-test'
    os.environ['HEALTH_ALERTS_TABLE'] = 'health-alerts-test'
    os.environ['AUDIT_LOG_TABLE'] = 'audit-log-test'
    os.environ['DATA_BUCKET'] = 'rds-dashboard-data-test'
    os.environ['EXTERNAL_ID'] = 'test-external-id'
    os.environ['TARGET_ACCOUNTS'] = '["123456789012"]'
    os.environ['TARGET_REGIONS'] = '["ap-southeast-1"]'
    os.environ['SNS_TOPIC_ARN'] = 'arn:aws:sns:ap-southeast-1:123456789012:test'
    
    # Run handler
    result = lambda_handler({}, MockContext())
    print(json.dumps(result, indent=2))

