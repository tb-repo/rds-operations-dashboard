﻿// Working BFF Handler with Real-Time RDS Discovery Integration (AWS SDK v3)
// This version calls the discovery service for real AWS RDS data
const { LambdaClient, InvokeCommand } = require('@aws-sdk/client-lambda');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

// Initialize AWS clients
const lambdaClient = new LambdaClient({
  region: process.env.AWS_REGION || 'ap-southeast-1'
});

const dynamodbClient = new DynamoDBClient({
  region: process.env.AWS_REGION || 'ap-southeast-1'
});

const docClient = DynamoDBDocumentClient.from(dynamodbClient);

// Configuration
const DISCOVERY_FUNCTION_NAME = process.env.DISCOVERY_FUNCTION_NAME || 'rds-discovery-service';
const CACHE_TABLE_NAME = process.env.CACHE_TABLE_NAME || 'rds-discovery-cache';
const CACHE_TTL_MINUTES = 5;

exports.handler = async (event, context) => {
  console.log('BFF Handler with Real-Time Discovery - Event:', JSON.stringify(event, null, 2));

  // Helper function to get cached data
  async function getCachedData(cacheKey) {
    try {
      const command = new GetCommand({
        TableName: CACHE_TABLE_NAME,
        Key: { cache_key: cacheKey }
      });
      
      const result = await docClient.send(command);
      
      if (result.Item) {
        const now = new Date();
        const expiresAt = new Date(result.Item.expires_at);
        
        if (now < expiresAt) {
          console.log('Cache hit - returning fresh data');
          return {
            data: result.Item.data,
            status: 'fresh',
            last_updated: result.Item.created_at
          };
        } else {
          console.log('Cache expired - will refresh');
          return {
            data: result.Item.data,
            status: 'stale',
            last_updated: result.Item.created_at
          };
        }
      }
      
      console.log('Cache miss - no data found');
      return null;
    } catch (error) {
      console.error('Cache read error:', error);
      return null;
    }
  }

  // Helper function to cache data
  async function setCachedData(cacheKey, data) {
    try {
      const now = new Date();
      const expiresAt = new Date(now.getTime() + (CACHE_TTL_MINUTES * 60 * 1000));
      
      const command = new PutCommand({
        TableName: CACHE_TABLE_NAME,
        Item: {
          cache_key: cacheKey,
          data: data,
          created_at: now.toISOString(),
          expires_at: expiresAt.toISOString(),
          ttl: Math.floor(expiresAt.getTime() / 1000) // DynamoDB TTL
        }
      });
      
      await docClient.send(command);
      console.log('Data cached successfully');
    } catch (error) {
      console.error('Cache write error:', error);
      // Don't fail the request if caching fails
    }
  }

  // Helper function to call discovery service
  async function callDiscoveryService() {
    try {
      console.log('Invoking discovery service:', DISCOVERY_FUNCTION_NAME);
      
      const command = new InvokeCommand({
        FunctionName: DISCOVERY_FUNCTION_NAME,
        InvocationType: 'RequestResponse',
        Payload: JSON.stringify({})
      });
      
      const result = await lambdaClient.send(command);
      
      if (result.StatusCode === 200) {
        const payload = JSON.parse(new TextDecoder().decode(result.Payload));
        
        if (payload.statusCode === 200) {
          const discoveryData = JSON.parse(payload.body);
          console.log(`Discovery service returned ${discoveryData.total_instances} instances`);
          return discoveryData;
        } else {
          throw new Error(`Discovery service returned status ${payload.statusCode}`);
        }
      } else {
        throw new Error(`Lambda invocation failed with status ${result.StatusCode}`);
      }
    } catch (error) {
      console.error('Discovery service error:', error);
      throw error;
    }
  }

  // Helper function to get instances with caching
  async function getInstancesWithCache() {
    const cacheKey = 'discovery_cache:instances';
    
    // Try to get cached data first
    const cachedResult = await getCachedData(cacheKey);
    
    if (cachedResult && cachedResult.status === 'fresh') {
      // Return fresh cached data
      return {
        ...cachedResult.data,
        metadata: {
          ...cachedResult.data.metadata,
          cache_status: 'fresh',
          last_updated: cachedResult.last_updated
        }
      };
    }
    
    try {
      // Call discovery service for fresh data
      const discoveryData = await callDiscoveryService();
      
      // Transform discovery data to BFF format
      const bffResponse = {
        instances: discoveryData.instances || [],
        metadata: {
          total_instances: discoveryData.total_instances || 0,
          accounts_scanned: discoveryData.accounts_scanned || 0,
          cache_status: 'fresh',
          last_updated: new Date().toISOString(),
          discovery_timestamp: discoveryData.discovery_timestamp
        }
      };
      
      // Cache the fresh data
      await setCachedData(cacheKey, bffResponse);
      
      return bffResponse;
      
    } catch (error) {
      console.error('Failed to get fresh data from discovery service:', error);
      
      // If we have stale cached data, return it with error indication
      if (cachedResult && cachedResult.data) {
        console.log('Returning stale cached data due to discovery service error');
        return {
          ...cachedResult.data,
          metadata: {
            ...cachedResult.data.metadata,
            cache_status: 'stale',
            last_updated: cachedResult.last_updated,
            error: 'Discovery service unavailable, showing cached data'
          }
        };
      }
      
      // No cached data available, return error
      throw new Error('Discovery service unavailable and no cached data available');
    }
  }
  
  try {
    // Extract request details from different event sources
    let httpMethod = 'GET';
    let path = '/';
    let headers = {};
    let queryStringParameters = null;
    let body = null;
    
    // Handle API Gateway event
    if (event.httpMethod && event.path) {
      httpMethod = event.httpMethod;
      path = event.path;
      headers = event.headers || {};
      queryStringParameters = event.queryStringParameters;
      body = event.body;
    }
    // Handle ALB event
    else if (event.requestContext && event.requestContext.elb) {
      httpMethod = event.httpMethod;
      path = event.path;
      headers = event.headers || {};
      queryStringParameters = event.queryStringParameters;
      body = event.body;
    }
    // Handle direct invocation with HTTP-like structure
    else if (event.method || event.url) {
      httpMethod = event.method || 'GET';
      path = event.url || '/';
      headers = event.headers || {};
    }
    
    console.log(`Processing ${httpMethod} ${path}`);
    
    // CORS headers for all responses - production-only origin
    const corsHeaders = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'https://d2qvaswtmn22om.cloudfront.net',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Credentials': 'true'
    };
    
    // Handle CORS preflight
    if (httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      };
    }
    
    // Handle /api/instances/{instanceId} endpoint - return specific instance
    if (path.match(/^\/api\/instances\/[^\/]+$/) || path.match(/\/api\/instances\/[^\/]+$/)) {
      const instanceId = path.split('/').pop();
      
      try {
        // Get all instances from discovery service
        const instancesData = await getInstancesWithCache();
        const instance = instancesData.instances.find(i => i.instance_id === instanceId);
        
        if (instance) {
          return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ 
              instance,
              metadata: {
                cache_status: instancesData.metadata.cache_status,
                last_updated: instancesData.metadata.last_updated
              }
            })
          };
        } else {
          return {
            statusCode: 404,
            headers: corsHeaders,
            body: JSON.stringify({
              error: 'Instance not found',
              message: `Instance ${instanceId} not found`,
              timestamp: new Date().toISOString()
            })
          };
        }
      } catch (error) {
        console.error('Error getting instance data:', error);
        return {
          statusCode: 500,
          headers: corsHeaders,
          body: JSON.stringify({
            error: 'Discovery service error',
            message: 'Unable to retrieve instance data',
            timestamp: new Date().toISOString()
          })
        };
      }
    }
    
    // Handle /api/instances endpoint - return all instances from discovery service
    if (path === '/api/instances' || path.endsWith('/api/instances')) {
      try {
        const instancesData = await getInstancesWithCache();
        
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(instancesData)
        };
      } catch (error) {
        console.error('Error getting instances data:', error);
        return {
          statusCode: 500,
          headers: corsHeaders,
          body: JSON.stringify({
            error: 'Discovery service error',
            message: 'Unable to retrieve instances data. Discovery service may be unavailable.',
            timestamp: new Date().toISOString(),
            fallback: false
          })
        };
      }
    }
    
    // Handle other endpoints with sample data (unchanged)
    // ... (keeping all other endpoint handlers the same)
    

    // Handle /api/operations endpoint - call operations Lambda
    if (path === '/api/operations' || path.endsWith('/api/operations')) {
      if (httpMethod === 'POST') {
        try {
          const operationsPayload = {
            httpMethod: 'POST',
            path: '/operations',
            body: body,
            requestContext: event.requestContext || {}
          };
          
          const operationsCommand = new InvokeCommand({
            FunctionName: 'rds-operations-prod',
            InvocationType: 'RequestResponse',
            Payload: JSON.stringify(operationsPayload)
          });
          
          const operationsResult = await lambdaClient.send(operationsCommand);
          
          if (operationsResult.StatusCode === 200) {
            const operationsResponse = JSON.parse(new TextDecoder().decode(operationsResult.Payload));
            
            return {
              statusCode: operationsResponse.statusCode || 200,
              headers: corsHeaders,
              body: operationsResponse.body || JSON.stringify({ success: true })
            };
          } else {
            return {
              statusCode: 500,
              headers: corsHeaders,
              body: JSON.stringify({
                error: 'Operations service error',
                message: 'Unable to process operation request',
                timestamp: new Date().toISOString()
              })
            };
          }
        } catch (error) {
          console.error('Operations service error:', error);
          return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({
              error: 'Operations service error',
              message: error.message,
              timestamp: new Date().toISOString()
            })
          };
        }
      } else {
        return {
          statusCode: 405,
          headers: corsHeaders,
          body: JSON.stringify({
            error: 'Method not allowed',
            message: 'Only POST method is supported for operations',
            timestamp: new Date().toISOString()
          })
        };
      }
    }

    // Default response
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'BFF is working with real-time discovery integration',
        path: path,
        method: httpMethod,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('BFF Handler Error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'https://d2qvaswtmn22om.cloudfront.net',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
