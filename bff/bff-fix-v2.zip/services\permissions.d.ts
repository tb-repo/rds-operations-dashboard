/**
 * Permission types in the system
 */
export type Permission = 'view_instances' | 'view_metrics' | 'view_compliance' | 'view_costs' | 'execute_operations' | 'generate_cloudops' | 'trigger_discovery' | 'manage_users';
/**
 * User roles in the system
 */
export type Role = 'Admin' | 'DBA' | 'ReadOnly';
/**
 * Endpoint-to-Permission mapping
 */
export declare const ENDPOINT_PERMISSIONS: Record<string, Permission>;
export declare class PermissionService {
    /**
     * Get all permissions for given roles/groups
     */
    getPermissionsForGroups(groups: string[]): Permission[];
    /**
     * Check if user has a specific permission
     */
    hasPermission(userPermissions: Permission[], requiredPermission: Permission): boolean;
    /**
     * Check if user has any of the specified permissions
     */
    hasAnyPermission(userPermissions: Permission[], requiredPermissions: Permission[]): boolean;
    /**
     * Check if user has all of the specified permissions
     */
    hasAllPermissions(userPermissions: Permission[], requiredPermissions: Permission[]): boolean;
    /**
     * Get required permission for an endpoint
     */
    getRequiredPermission(method: string, path: string): Permission | null;
    /**
     * Match request against endpoint pattern
     */
    private matchesPattern;
    /**
     * Check if a string is a valid role
     */
    private isValidRole;
    /**
     * Get all permissions for a specific role
     */
    getRolePermissions(role: Role): Permission[];
    /**
     * Get all available permissions
     */
    getAllPermissions(): Permission[];
    /**
     * Get all available roles
     */
    getAllRoles(): Role[];
    /**
     * Get role description
     */
    getRoleDescription(role: Role): string;
    /**
     * Get permission description
     */
    getPermissionDescription(permission: Permission): string;
}
export declare const permissionService: PermissionService;
//# sourceMappingURL=permissions.d.ts.map