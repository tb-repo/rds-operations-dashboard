"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtValidator = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const jwks_rsa_1 = __importDefault(require("jwks-rsa"));
const logger_1 = require("../utils/logger");
class JwtValidator {
    constructor(userPoolId, region, clientId) {
        this.CACHE_TTL = 3600000; // 1 hour in milliseconds
        this.issuer = `https://cognito-idp.${region}.amazonaws.com/${userPoolId}`;
        this.audience = clientId;
        // Initialize JWKS client to fetch Cognito public keys
        this.jwksClient = (0, jwks_rsa_1.default)({
            jwksUri: `${this.issuer}/.well-known/jwks.json`,
            cache: true,
            cacheMaxAge: this.CACHE_TTL,
            rateLimit: true,
            jwksRequestsPerMinute: 10,
        });
        this.keyCache = new Map();
        this.cacheExpiry = new Map();
        logger_1.logger.info('JWT Validator initialized', {
            issuer: this.issuer,
            audience: this.audience,
        });
    }
    /**
     * Validate JWT token from Cognito
     */
    async validateToken(token) {
        try {
            // Decode token without verification to get header
            const decoded = jsonwebtoken_1.default.decode(token, { complete: true });
            if (!decoded || typeof decoded === 'string') {
                return {
                    valid: false,
                    error: 'Invalid token format',
                };
            }
            const { header, payload } = decoded;
            // Verify token has required fields
            if (!header.kid) {
                return {
                    valid: false,
                    error: 'Token missing key ID (kid)',
                };
            }
            // Get signing key
            const signingKey = await this.getSigningKey(header.kid);
            if (!signingKey) {
                return {
                    valid: false,
                    error: 'Unable to find signing key',
                };
            }
            // Verify token signature and claims
            const verifiedPayload = await this.verifyTokenSignature(token, signingKey.getPublicKey());
            if (!verifiedPayload) {
                return {
                    valid: false,
                    error: 'Token signature verification failed',
                };
            }
            // Validate token claims
            const claimsValid = this.validateClaims(verifiedPayload);
            if (!claimsValid.valid) {
                return claimsValid;
            }
            logger_1.logger.debug('Token validated successfully', {
                sub: verifiedPayload.sub,
                email: verifiedPayload.email,
            });
            return {
                valid: true,
                payload: verifiedPayload,
            };
        }
        catch (error) {
            logger_1.logger.error('Token validation error', {
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return {
                valid: false,
                error: error instanceof Error ? error.message : 'Token validation failed',
            };
        }
    }
    /**
     * Get signing key from JWKS endpoint with caching
     */
    async getSigningKey(kid) {
        try {
            // Check cache first
            const cached = this.keyCache.get(kid);
            const expiry = this.cacheExpiry.get(kid);
            if (cached && expiry && Date.now() < expiry) {
                logger_1.logger.debug('Using cached signing key', { kid });
                return cached;
            }
            // Fetch from JWKS endpoint
            logger_1.logger.debug('Fetching signing key from JWKS', { kid });
            const key = await this.jwksClient.getSigningKey(kid);
            // Cache the key
            this.keyCache.set(kid, key);
            this.cacheExpiry.set(kid, Date.now() + this.CACHE_TTL);
            return key;
        }
        catch (error) {
            logger_1.logger.error('Error fetching signing key', {
                kid,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return null;
        }
    }
    /**
     * Verify token signature using public key
     */
    async verifyTokenSignature(token, publicKey) {
        try {
            const verifyOptions = {
                issuer: this.issuer,
                algorithms: ['RS256'],
            };
            if (this.audience) {
                verifyOptions.audience = this.audience;
            }
            const payload = jsonwebtoken_1.default.verify(token, publicKey, verifyOptions);
            return payload;
        }
        catch (error) {
            logger_1.logger.error('Token signature verification failed', {
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return null;
        }
    }
    /**
     * Validate token claims
     */
    validateClaims(payload) {
        // Check token use
        if (payload.token_use !== 'id' && payload.token_use !== 'access') {
            return {
                valid: false,
                error: 'Invalid token use',
            };
        }
        // Check expiration
        if (payload.exp && Date.now() >= payload.exp * 1000) {
            return {
                valid: false,
                error: 'Token has expired',
            };
        }
        // Check not before
        if (payload.nbf && Date.now() < payload.nbf * 1000) {
            return {
                valid: false,
                error: 'Token not yet valid',
            };
        }
        // Check issuer
        if (payload.iss !== this.issuer) {
            return {
                valid: false,
                error: 'Invalid token issuer',
            };
        }
        // Check required fields
        if (!payload.sub || !payload.email) {
            return {
                valid: false,
                error: 'Token missing required claims',
            };
        }
        return {
            valid: true,
            payload,
        };
    }
    /**
     * Check if token is expired
     */
    isTokenExpired(token) {
        try {
            const decoded = jsonwebtoken_1.default.decode(token);
            if (!decoded || !decoded.exp) {
                return true;
            }
            return Date.now() >= decoded.exp * 1000;
        }
        catch {
            return true;
        }
    }
    /**
     * Extract payload without verification (for debugging)
     */
    decodeToken(token) {
        try {
            const decoded = jsonwebtoken_1.default.decode(token);
            return decoded;
        }
        catch {
            return null;
        }
    }
}
exports.JwtValidator = JwtValidator;
//# sourceMappingURL=jwt-validator.js.map