/**
 * Lambda Handler for BFF using @vendia/serverless-express
 *
 * This file wraps the Express application for AWS Lambda execution.
 * It uses serverless-express to handle the conversion between Lambda events
 * and Express HTTP requests/responses.
 */
export declare const handler: any;
//# sourceMappingURL=lambda.d.ts.map