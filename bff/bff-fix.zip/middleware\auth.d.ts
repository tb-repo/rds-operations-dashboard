import { Request, Response, NextFunction } from 'express';
declare global {
    namespace Express {
        interface Request {
            user?: UserContext;
        }
    }
}
export interface UserContext {
    userId: string;
    email: string;
    name?: string;
    groups: string[];
    permissions: string[];
    sessionId: string;
    authTime: number;
    tokenExpiry: number;
}
export declare class AuthMiddleware {
    private jwtValidator;
    constructor(userPoolId: string, region: string, clientId?: string);
    /**
     * Middleware to authenticate requests
     */
    authenticate(): (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Extract JWT token from Authorization header
     */
    private extractToken;
    /**
     * Extract user context from validated token payload
     */
    private extractUserContext;
    /**
     * Map user groups to permissions
     * This will be enhanced in the permission mapping service
     */
    private getPermissionsForGroups;
    /**
     * Get permissions for a specific group
     */
    private getGroupPermissions;
    /**
     * Determine error code from validation error message
     */
    private getErrorCode;
    /**
     * Optional middleware to check if token is about to expire
     */
    checkTokenExpiry(warningThresholdMinutes?: number): (req: Request, res: Response, next: NextFunction) => void;
}
//# sourceMappingURL=auth.d.ts.map