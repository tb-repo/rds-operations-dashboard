"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthorizationMiddleware = void 0;
const permissions_1 = require("../services/permissions");
const logger_1 = require("../utils/logger");
const audit_1 = require("../services/audit");
const axios_1 = __importDefault(require("axios"));
class AuthorizationMiddleware {
    constructor(internalApiUrl, apiKey) {
        this.internalApiUrl = internalApiUrl;
        this.apiKey = apiKey;
        logger_1.logger.info('Authorization middleware initialized');
    }
    /**
     * Middleware to authorize requests based on permissions
     */
    authorize(requiredPermission) {
        return async (req, res, next) => {
            try {
                // Check if user is authenticated
                if (!req.user) {
                    logger_1.logger.warn('Authorization failed: User not authenticated', {
                        path: req.path,
                        method: req.method,
                    });
                    return res.status(401).json({
                        error: 'Unauthorized',
                        message: 'Authentication required',
                        code: 'AUTH_REQUIRED',
                    });
                }
                // Determine required permission
                const permission = requiredPermission ||
                    permissions_1.permissionService.getRequiredPermission(req.method, req.path);
                if (!permission) {
                    // No specific permission required, allow access
                    logger_1.logger.debug('No permission required for endpoint', {
                        path: req.path,
                        method: req.method,
                    });
                    return next();
                }
                // Check if user has required permission
                const hasPermission = permissions_1.permissionService.hasPermission(req.user.permissions, permission);
                if (!hasPermission) {
                    logger_1.logger.warn('Authorization denied: Insufficient permissions', {
                        userId: req.user.userId,
                        email: req.user.email,
                        requiredPermission: permission,
                        userPermissions: req.user.permissions,
                        path: req.path,
                        method: req.method,
                    });
                    // Log authorization denial
                    audit_1.auditService.logAuthorizationEvent('AUTHZ_DENIED', req.user.userId, req.user.email, req.ip || 'unknown', req.get('user-agent') || 'unknown', req.path, req.method, 'failure', undefined, {
                        requiredPermission: permission,
                        userPermissions: req.user.permissions,
                        reason: 'Insufficient permissions',
                    });
                    return res.status(403).json({
                        error: 'Forbidden',
                        message: 'Insufficient permissions to perform this action',
                        code: 'INSUFFICIENT_PERMISSIONS',
                        requiredPermission: permission,
                        userPermissions: req.user.permissions,
                    });
                }
                // Additional checks for operations endpoints
                if (permission === 'execute_operations') {
                    const instanceId = this.extractInstanceId(req);
                    if (instanceId) {
                        const canOperate = await this.canOperateOnInstance(req.user.userId, instanceId, req.body.operation || 'unknown');
                        if (!canOperate.allowed) {
                            logger_1.logger.warn('Authorization denied: Production instance protection', {
                                userId: req.user.userId,
                                email: req.user.email,
                                instanceId,
                                operation: req.body.operation,
                                reason: canOperate.reason,
                            });
                            // Log authorization denial for production protection
                            audit_1.auditService.logAuthorizationEvent('AUTHZ_DENIED', req.user.userId, req.user.email, req.ip || 'unknown', req.get('user-agent') || 'unknown', `instance:${instanceId}`, req.body.operation || 'operation', 'failure', undefined, {
                                reason: 'Production instance protection',
                                instanceId,
                                environment: 'production',
                            });
                            return res.status(403).json({
                                error: 'Forbidden',
                                message: canOperate.reason || 'Operations on production instances are not allowed',
                                code: 'PRODUCTION_PROTECTED',
                                instanceId,
                                environment: 'production',
                            });
                        }
                    }
                }
                logger_1.logger.debug('Authorization granted', {
                    userId: req.user.userId,
                    email: req.user.email,
                    permission,
                    path: req.path,
                    method: req.method,
                });
                // Log authorization granted
                audit_1.auditService.logAuthorizationEvent('AUTHZ_GRANTED', req.user.userId, req.user.email, req.ip || 'unknown', req.get('user-agent') || 'unknown', req.path, req.method, 'success', undefined, {
                    permission,
                });
                next();
            }
            catch (error) {
                logger_1.logger.error('Authorization error', {
                    error: error instanceof Error ? error.message : 'Unknown error',
                    path: req.path,
                    method: req.method,
                });
                res.status(500).json({
                    error: 'Internal Server Error',
                    message: 'Authorization service error',
                    code: 'AUTHZ_SERVICE_ERROR',
                });
            }
        };
    }
    /**
     * Check if user can operate on a specific instance
     */
    async canOperateOnInstance(userId, instanceId, operation) {
        try {
            // Fetch instance details from internal API
            const instance = await this.getInstanceDetails(instanceId);
            if (!instance) {
                return {
                    allowed: false,
                    reason: 'Instance not found',
                };
            }
            // Check if instance is production
            if (instance.environment === 'production') {
                // Check if production operations are enabled via environment variable
                const enableProductionOps = process.env.ENABLE_PRODUCTION_OPERATIONS === 'true';
                if (!enableProductionOps) {
                    logger_1.logger.info('Blocking operation on production instance', {
                        userId,
                        instanceId,
                        operation,
                        environment: instance.environment,
                    });
                    return {
                        allowed: false,
                        reason: 'Operations on production instances are not allowed. Use CloudOps to generate a change request instead.',
                    };
                }
                // Production operations are enabled - allow with warning
                logger_1.logger.warn('Allowing operation on production instance (production operations enabled)', {
                    userId,
                    instanceId,
                    operation,
                    environment: instance.environment,
                });
            }
            // Allow operations on non-production instances
            return {
                allowed: true,
            };
        }
        catch (error) {
            logger_1.logger.error('Error checking instance operability', {
                userId,
                instanceId,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            // Fail closed - deny access if we can't determine environment
            return {
                allowed: false,
                reason: 'Unable to verify instance environment',
            };
        }
    }
    /**
     * Get instance details from internal API
     */
    async getInstanceDetails(instanceId) {
        try {
            const response = await axios_1.default.get(`${this.internalApiUrl}/instances/${instanceId}`, {
                headers: {
                    'x-api-key': this.apiKey,
                },
                timeout: 5000,
            });
            return response.data;
        }
        catch (error) {
            logger_1.logger.error('Error fetching instance details', {
                instanceId,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return null;
        }
    }
    /**
     * Extract instance ID from request
     */
    extractInstanceId(req) {
        // Check body
        if (req.body && req.body.instance_id) {
            return req.body.instance_id;
        }
        // Check params
        if (req.params && req.params.instanceId) {
            return req.params.instanceId;
        }
        if (req.params && req.params.id) {
            return req.params.id;
        }
        // Check query
        if (req.query && req.query.instance_id) {
            return req.query.instance_id;
        }
        return null;
    }
    /**
     * Middleware to require specific permission
     */
    requirePermission(permission) {
        return this.authorize(permission);
    }
    /**
     * Middleware to require any of the specified permissions
     */
    requireAnyPermission(permissions) {
        return (req, res, next) => {
            if (!req.user) {
                return res.status(401).json({
                    error: 'Unauthorized',
                    message: 'Authentication required',
                    code: 'AUTH_REQUIRED',
                });
            }
            const hasAny = permissions_1.permissionService.hasAnyPermission(req.user.permissions, permissions);
            if (!hasAny) {
                logger_1.logger.warn('Authorization denied: Missing any required permission', {
                    userId: req.user.userId,
                    requiredPermissions: permissions,
                    userPermissions: req.user.permissions,
                });
                return res.status(403).json({
                    error: 'Forbidden',
                    message: 'Insufficient permissions to perform this action',
                    code: 'INSUFFICIENT_PERMISSIONS',
                    requiredPermissions: permissions,
                    userPermissions: req.user.permissions,
                });
            }
            next();
        };
    }
    /**
     * Middleware to require all of the specified permissions
     */
    requireAllPermissions(permissions) {
        return (req, res, next) => {
            if (!req.user) {
                return res.status(401).json({
                    error: 'Unauthorized',
                    message: 'Authentication required',
                    code: 'AUTH_REQUIRED',
                });
            }
            const hasAll = permissions_1.permissionService.hasAllPermissions(req.user.permissions, permissions);
            if (!hasAll) {
                logger_1.logger.warn('Authorization denied: Missing required permissions', {
                    userId: req.user.userId,
                    requiredPermissions: permissions,
                    userPermissions: req.user.permissions,
                });
                return res.status(403).json({
                    error: 'Forbidden',
                    message: 'Insufficient permissions to perform this action',
                    code: 'INSUFFICIENT_PERMISSIONS',
                    requiredPermissions: permissions,
                    userPermissions: req.user.permissions,
                });
            }
            next();
        };
    }
}
exports.AuthorizationMiddleware = AuthorizationMiddleware;
//# sourceMappingURL=authorization.js.map