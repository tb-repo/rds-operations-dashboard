"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CognitoAdminService = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const logger_1 = require("../utils/logger");
class CognitoAdminService {
    constructor(region, userPoolId) {
        this.client = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region });
        this.userPoolId = userPoolId;
        logger_1.logger.info('Cognito admin service initialized', { userPoolId });
    }
    /**
     * List all users in the user pool
     */
    async listUsers(limit = 60, paginationToken) {
        try {
            const command = new client_cognito_identity_provider_1.ListUsersCommand({
                UserPoolId: this.userPoolId,
                Limit: limit,
                PaginationToken: paginationToken,
            });
            const response = await this.client.send(command);
            const users = (response.Users || []).map(user => this.mapCognitoUser(user));
            return {
                users,
                total: users.length,
                nextToken: response.PaginationToken,
            };
        }
        catch (error) {
            logger_1.logger.error('Error listing users', {
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            throw new Error('Failed to list users');
        }
    }
    /**
     * Get details for a specific user
     */
    async getUserDetails(username) {
        try {
            const command = new client_cognito_identity_provider_1.AdminGetUserCommand({
                UserPoolId: this.userPoolId,
                Username: username,
            });
            const response = await this.client.send(command);
            // Get user groups
            const groups = await this.getUserGroups(username);
            return {
                id: response.Username || username,
                email: this.getAttributeValue(response.UserAttributes, 'email') || '',
                name: this.getAttributeValue(response.UserAttributes, 'name'),
                groups,
                status: response.UserStatus || 'UNKNOWN',
                createdAt: response.UserCreateDate?.toISOString() || '',
                lastLogin: response.UserLastModifiedDate?.toISOString(),
                attributes: this.mapAttributes(response.UserAttributes),
            };
        }
        catch (error) {
            logger_1.logger.error('Error getting user details', {
                username,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return null;
        }
    }
    /**
     * Get groups for a user
     */
    async getUserGroups(username) {
        try {
            const command = new client_cognito_identity_provider_1.AdminListGroupsForUserCommand({
                UserPoolId: this.userPoolId,
                Username: username,
            });
            const response = await this.client.send(command);
            return (response.Groups || []).map(group => group.GroupName || '').filter(name => name);
        }
        catch (error) {
            logger_1.logger.error('Error getting user groups', {
                username,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return [];
        }
    }
    /**
     * Add user to a group (assign role)
     */
    async addUserToGroup(username, groupName) {
        try {
            const command = new client_cognito_identity_provider_1.AdminAddUserToGroupCommand({
                UserPoolId: this.userPoolId,
                Username: username,
                GroupName: groupName,
            });
            await this.client.send(command);
            logger_1.logger.info('User added to group', { username, groupName });
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error adding user to group', {
                username,
                groupName,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            throw new Error(`Failed to add user to group: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Remove user from a group (revoke role)
     */
    async removeUserFromGroup(username, groupName) {
        try {
            const command = new client_cognito_identity_provider_1.AdminRemoveUserFromGroupCommand({
                UserPoolId: this.userPoolId,
                Username: username,
                GroupName: groupName,
            });
            await this.client.send(command);
            logger_1.logger.info('User removed from group', { username, groupName });
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error removing user from group', {
                username,
                groupName,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            throw new Error(`Failed to remove user from group: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Map Cognito user to UserInfo
     */
    mapCognitoUser(cognitoUser) {
        return {
            id: cognitoUser.Username || '',
            email: this.getAttributeValue(cognitoUser.Attributes, 'email') || '',
            name: this.getAttributeValue(cognitoUser.Attributes, 'name'),
            groups: [], // Will be populated separately if needed
            status: cognitoUser.UserStatus || 'UNKNOWN',
            createdAt: cognitoUser.UserCreateDate?.toISOString() || '',
            lastLogin: cognitoUser.UserLastModifiedDate?.toISOString(),
            attributes: this.mapAttributes(cognitoUser.Attributes),
        };
    }
    /**
     * Get attribute value from Cognito attributes array
     */
    getAttributeValue(attributes, name) {
        if (!attributes)
            return undefined;
        const attr = attributes.find(a => a.Name === name);
        return attr?.Value;
    }
    /**
     * Map Cognito attributes to key-value object
     */
    mapAttributes(attributes) {
        if (!attributes)
            return {};
        const mapped = {};
        for (const attr of attributes) {
            if (attr.Name && attr.Value) {
                mapped[attr.Name] = attr.Value;
            }
        }
        return mapped;
    }
}
exports.CognitoAdminService = CognitoAdminService;
//# sourceMappingURL=cognito-admin.js.map