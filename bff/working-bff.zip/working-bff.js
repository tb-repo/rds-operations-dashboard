﻿// Working BFF Handler for rds-dashboard-bff
// This is the Lambda function that the frontend actually calls
exports.handler = async (event, context) => {
  console.log('Working BFF Handler - Event:', JSON.stringify(event, null, 2));
  
  try {
    // Extract request details from different event sources
    let httpMethod = 'GET';
    let path = '/';
    let headers = {};
    let queryStringParameters = null;
    let body = null;
    
    // Handle API Gateway event
    if (event.httpMethod && event.path) {
      httpMethod = event.httpMethod;
      path = event.path;
      headers = event.headers || {};
      queryStringParameters = event.queryStringParameters;
      body = event.body;
    }
    // Handle ALB event
    else if (event.requestContext && event.requestContext.elb) {
      httpMethod = event.httpMethod;
      path = event.path;
      headers = event.headers || {};
      queryStringParameters = event.queryStringParameters;
      body = event.body;
    }
    // Handle direct invocation with HTTP-like structure
    else if (event.method || event.url) {
      httpMethod = event.method || 'GET';
      path = event.url || '/';
      headers = event.headers || {};
    }
    
    console.log(`Processing ${httpMethod} ${path}`);
    
    // CORS headers for all responses
    const corsHeaders = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
    };
    
    // Handle CORS preflight
    if (httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      };
    }
    
    // Handle error dashboard endpoint
    if (path === '/api/errors/dashboard' || path.endsWith('/api/errors/dashboard')) {
      const dashboardData = {
        status: 'fallback',
        message: 'Dashboard data temporarily unavailable',
        widgets: {
          error_metrics: {
            title: 'Error Metrics',
            data: {
              total_errors: 0,
              breakdown: {
                by_severity: { critical: 0, high: 0, medium: 0, low: 0 },
                by_service: {},
                error_rates: {}
              }
            },
            status: 'unavailable'
          },
          system_health: {
            title: 'System Health',
            data: {
              indicators: {
                total_errors: 0,
                critical_errors: 0,
                high_errors: 0,
                services_affected: 0
              }
            },
            status: 'unavailable'
          }
        },
        last_updated: new Date().toISOString(),
        fallback: true
      };
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(dashboardData)
      };
    }
    
    // Handle error statistics endpoint
    if (path === '/api/errors/statistics' || path.endsWith('/api/errors/statistics')) {
      const statisticsData = {
        status: 'unavailable',
        message: 'Error statistics service is temporarily unavailable',
        fallback: true,
        statistics: {
          total_errors_detected: 0,
          detector_version: '1.0.0',
          patterns_loaded: 0,
          critical_errors: 0,
          high_errors: 0,
          services_affected: 0
        },
        errors_by_severity: {
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        },
        errors_by_service: {},
        error_rates: {},
        timestamp: new Date().toISOString()
      };
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(statisticsData)
      };
    }
    
    // Handle other API endpoints with basic responses
    if (path.includes('/api/')) {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          message: 'API endpoint temporarily unavailable',
          path: path,
          timestamp: new Date().toISOString()
        })
      };
    }
    
    // Default response
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'BFF is working',
        path: path,
        method: httpMethod,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('BFF Handler Error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
