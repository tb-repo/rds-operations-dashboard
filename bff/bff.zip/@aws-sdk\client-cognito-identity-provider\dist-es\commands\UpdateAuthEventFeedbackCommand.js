import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { UpdateAuthEventFeedback } from "../schemas/schemas_0";
export { $Command };
export class UpdateAuthEventFeedbackCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSCognitoIdentityProviderService", "UpdateAuthEventFeedback", {})
    .n("CognitoIdentityProviderClient", "UpdateAuthEventFeedbackCommand")
    .sc(UpdateAuthEventFeedback)
    .build() {
}
