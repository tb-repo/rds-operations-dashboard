import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { ChangePassword } from "../schemas/schemas_0";
export { $Command };
export class ChangePasswordCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSCognitoIdentityProviderService", "ChangePassword", {})
    .n("CognitoIdentityProviderClient", "ChangePasswordCommand")
    .sc(ChangePassword)
    .build() {
}
