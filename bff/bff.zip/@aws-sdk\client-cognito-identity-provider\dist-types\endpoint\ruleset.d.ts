import { RuleSetObject } from "@smithy/types";
export declare const ruleSet: RuleSetObject;
