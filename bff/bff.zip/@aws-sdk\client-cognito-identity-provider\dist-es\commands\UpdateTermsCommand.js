import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { UpdateTerms } from "../schemas/schemas_0";
export { $Command };
export class UpdateTermsCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSCognitoIdentityProviderService", "UpdateTerms", {})
    .n("CognitoIdentityProviderClient", "UpdateTermsCommand")
    .sc(UpdateTerms)
    .build() {
}
