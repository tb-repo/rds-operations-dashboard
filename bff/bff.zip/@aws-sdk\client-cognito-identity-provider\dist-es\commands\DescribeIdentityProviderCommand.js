import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { DescribeIdentityProvider } from "../schemas/schemas_0";
export { $Command };
export class DescribeIdentityProviderCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSCognitoIdentityProviderService", "DescribeIdentityProvider", {})
    .n("CognitoIdentityProviderClient", "DescribeIdentityProviderCommand")
    .sc(DescribeIdentityProvider)
    .build() {
}
