import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { AdminRemoveUserFromGroup } from "../schemas/schemas_0";
export { $Command };
export class AdminRemoveUserFromGroupCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSCognitoIdentityProviderService", "AdminRemoveUserFromGroup", {})
    .n("CognitoIdentityProviderClient", "AdminRemoveUserFromGroupCommand")
    .sc(AdminRemoveUserFromGroup)
    .build() {
}
