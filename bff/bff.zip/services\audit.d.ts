/**
 * Audit event types
 */
export type AuditEventType = 'AUTH_LOGIN_SUCCESS' | 'AUTH_LOGIN_FAILURE' | 'AUTH_LOGOUT' | 'AUTH_TOKEN_REFRESH' | 'AUTHZ_DENIED' | 'AUTHZ_GRANTED' | 'OPERATION_EXECUTED' | 'CLOUDOPS_GENERATED' | 'USER_ROLE_CHANGED' | 'DISCOVERY_TRIGGERED' | 'APPROVAL_REQUEST_CREATED' | 'APPROVAL_GRANTED' | 'APPROVAL_REJECTED' | 'ERROR_DETECTION' | 'ERROR_RESOLUTION' | 'ERROR_ROLLBACK';
/**
 * Audit log entry structure
 */
export interface AuditLogEntry {
    timestamp: string;
    eventType: AuditEventType;
    userId: string;
    userEmail: string;
    ipAddress: string;
    userAgent: string;
    resource?: string;
    action?: string;
    result: 'success' | 'failure';
    statusCode?: number;
    errorMessage?: string;
    requestId?: string;
    metadata?: Record<string, any>;
}
/**
 * Audit logging service
 */
export declare class AuditService {
    private enabled;
    constructor(enabled?: boolean);
    /**
     * Log authentication event
     */
    logAuthenticationEvent(eventType: 'AUTH_LOGIN_SUCCESS' | 'AUTH_LOGIN_FAILURE' | 'AUTH_LOGOUT' | 'AUTH_TOKEN_REFRESH', userId: string, userEmail: string, ipAddress: string, userAgent: string, result: 'success' | 'failure', metadata?: Record<string, any>): void;
    /**
     * Log authorization event
     */
    logAuthorizationEvent(eventType: 'AUTHZ_GRANTED' | 'AUTHZ_DENIED', userId: string, userEmail: string, ipAddress: string, userAgent: string, resource: string, action: string, result: 'success' | 'failure', requestId?: string, metadata?: Record<string, any>): void;
    /**
     * Log operation event
     */
    logOperationEvent(eventType: Extract<AuditEventType, 'OPERATION_EXECUTED' | 'CLOUDOPS_GENERATED' | 'DISCOVERY_TRIGGERED' | 'APPROVAL_REQUEST_CREATED' | 'APPROVAL_GRANTED' | 'APPROVAL_REJECTED' | 'ERROR_DETECTION' | 'ERROR_RESOLUTION' | 'ERROR_ROLLBACK'>, userId: string, userEmail: string, ipAddress: string, userAgent: string, resource: string, action: string, result: 'success' | 'failure', requestId?: string, metadata?: Record<string, any>): void;
    /**
     * Log user role change event
     */
    logUserRoleChange(adminUserId: string, adminEmail: string, targetUserId: string, targetEmail: string, action: 'add_role' | 'remove_role', role: string, ipAddress: string, userAgent: string, result: 'success' | 'failure', requestId?: string, metadata?: Record<string, any>): void;
    /**
     * Write audit log entry to CloudWatch Logs
     */
    private writeAuditLog;
    /**
     * Enable audit logging
     */
    enable(): void;
    /**
     * Disable audit logging
     */
    disable(): void;
    /**
     * Check if audit logging is enabled
     */
    isEnabled(): boolean;
}
export declare const auditService: AuditService;
//# sourceMappingURL=audit.d.ts.map