import { Request, Response, NextFunction } from 'express';
import { Permission } from '../services/permissions';
export interface ResourceContext {
    instanceId?: string;
    environment?: string;
    operation?: string;
}
export interface AuthorizationResult {
    allowed: boolean;
    reason?: string;
    requiredPermission?: Permission;
}
export declare class AuthorizationMiddleware {
    private internalApiUrl;
    private apiKey;
    constructor(internalApiUrl: string, apiKey: string);
    /**
     * Middleware to authorize requests based on permissions
     */
    authorize(requiredPermission?: Permission): (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
    /**
     * Check if user can operate on a specific instance
     */
    private canOperateOnInstance;
    /**
     * Get instance details from internal API
     */
    private getInstanceDetails;
    /**
     * Extract instance ID from request
     */
    private extractInstanceId;
    /**
     * Middleware to require specific permission
     */
    requirePermission(permission: Permission): (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
    /**
     * Middleware to require any of the specified permissions
     */
    requireAnyPermission(permissions: Permission[]): (req: Request, res: Response, next: NextFunction) => Response<any, Record<string, any>> | undefined;
    /**
     * Middleware to require all of the specified permissions
     */
    requireAllPermissions(permissions: Permission[]): (req: Request, res: Response, next: NextFunction) => Response<any, Record<string, any>> | undefined;
}
//# sourceMappingURL=authorization.d.ts.map