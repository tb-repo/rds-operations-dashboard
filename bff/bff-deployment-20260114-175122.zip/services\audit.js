"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditService = exports.AuditService = void 0;
const logger_1 = require("../utils/logger");
/**
 * Audit logging service
 */
class AuditService {
    constructor(enabled = true) {
        this.enabled = enabled;
        logger_1.logger.info('Audit service initialized', { enabled: this.enabled });
    }
    /**
     * Log authentication event
     */
    logAuthenticationEvent(eventType, userId, userEmail, ipAddress, userAgent, result, metadata) {
        const entry = {
            timestamp: new Date().toISOString(),
            eventType,
            userId,
            userEmail,
            ipAddress,
            userAgent,
            result,
            metadata,
        };
        this.writeAuditLog(entry);
    }
    /**
     * Log authorization event
     */
    logAuthorizationEvent(eventType, userId, userEmail, ipAddress, userAgent, resource, action, result, requestId, metadata) {
        const entry = {
            timestamp: new Date().toISOString(),
            eventType,
            userId,
            userEmail,
            ipAddress,
            userAgent,
            resource,
            action,
            result,
            requestId,
            metadata,
        };
        this.writeAuditLog(entry);
    }
    /**
     * Log operation event
     */
    logOperationEvent(eventType, userId, userEmail, ipAddress, userAgent, resource, action, result, requestId, metadata) {
        const entry = {
            timestamp: new Date().toISOString(),
            eventType,
            userId,
            userEmail,
            ipAddress,
            userAgent,
            resource,
            action,
            result,
            requestId,
            metadata,
        };
        this.writeAuditLog(entry);
    }
    /**
     * Log user role change event
     */
    logUserRoleChange(adminUserId, adminEmail, targetUserId, targetEmail, action, role, ipAddress, userAgent, result, requestId, metadata) {
        const entry = {
            timestamp: new Date().toISOString(),
            eventType: 'USER_ROLE_CHANGED',
            userId: adminUserId,
            userEmail: adminEmail,
            ipAddress,
            userAgent,
            resource: `user:${targetUserId}`,
            action,
            result,
            requestId,
            metadata: {
                ...metadata,
                targetUserId,
                targetEmail,
                role,
            },
        };
        this.writeAuditLog(entry);
    }
    /**
     * Write audit log entry to CloudWatch Logs
     */
    writeAuditLog(entry) {
        if (!this.enabled) {
            return;
        }
        // Log to structured logger which will send to CloudWatch
        logger_1.logger.info('AUDIT_LOG', entry);
        // Additional CloudWatch Logs integration can be added here
        // For now, we rely on the Winston logger configuration
        // to send logs to CloudWatch Logs
    }
    /**
     * Enable audit logging
     */
    enable() {
        this.enabled = true;
        logger_1.logger.info('Audit logging enabled');
    }
    /**
     * Disable audit logging
     */
    disable() {
        this.enabled = false;
        logger_1.logger.warn('Audit logging disabled');
    }
    /**
     * Check if audit logging is enabled
     */
    isEnabled() {
        return this.enabled;
    }
}
exports.AuditService = AuditService;
// Export singleton instance
exports.auditService = new AuditService(process.env.ENABLE_AUDIT_LOGGING !== 'false');
//# sourceMappingURL=audit.js.map