import { Router } from 'express';
import { CognitoAdminService } from '../services/cognito-admin';
export declare function createUserRoutes(cognitoAdminService: CognitoAdminService): Router;
//# sourceMappingURL=users.d.ts.map