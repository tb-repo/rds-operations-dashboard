/**
 * Enhanced OPTIONS Request Handler Middleware
 *
 * Ensures all API routes properly support OPTIONS method for CORS preflight requests.
 * Provides comprehensive CORS headers and validation for preflight requests.
 */
import { Request, Response, NextFunction } from 'express';
export interface OptionsHandlerConfig {
    allowedOrigins: string[];
    allowedMethods: string[];
    allowedHeaders: string[];
    exposedHeaders: string[];
    maxAge: number;
    credentials: boolean;
}
/**
 * Creates an OPTIONS request handler middleware
 */
export declare const createOptionsHandler: (config: OptionsHandlerConfig) => (req: Request, res: Response, next: NextFunction) => void | Response<any, Record<string, any>>;
/**
 * Middleware to add CORS headers to all responses (not just OPTIONS)
 */
export declare const addCorsHeaders: (config: OptionsHandlerConfig) => (req: Request, res: Response, next: NextFunction) => void;
/**
 * Comprehensive OPTIONS route handler for catch-all routes
 */
export declare const handleAllOptions: (config: OptionsHandlerConfig) => (req: Request, res: Response) => void;
//# sourceMappingURL=options-handler.d.ts.map