"use strict";
/**
 * Enhanced OPTIONS Request Handler Middleware
 *
 * Ensures all API routes properly support OPTIONS method for CORS preflight requests.
 * Provides comprehensive CORS headers and validation for preflight requests.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleAllOptions = exports.addCorsHeaders = exports.createOptionsHandler = void 0;
const logger_1 = require("../utils/logger");
/**
 * Creates an OPTIONS request handler middleware
 */
const createOptionsHandler = (config) => {
    return (req, res, next) => {
        // Only handle OPTIONS requests
        if (req.method !== 'OPTIONS') {
            return next();
        }
        const origin = req.get('Origin');
        const requestMethod = req.get('Access-Control-Request-Method');
        const requestHeaders = req.get('Access-Control-Request-Headers');
        logger_1.logger.debug('Handling OPTIONS preflight request', {
            origin,
            requestMethod,
            requestHeaders,
            path: req.path
        });
        // Validate origin if present
        if (origin) {
            if (!config.allowedOrigins.includes(origin)) {
                logger_1.logger.warn('OPTIONS request blocked: unauthorized origin', {
                    origin,
                    allowedOrigins: config.allowedOrigins
                });
                return res.status(403).json({ error: 'Origin not allowed' });
            }
            res.header('Access-Control-Allow-Origin', origin);
        }
        // Validate requested method
        if (requestMethod) {
            if (!config.allowedMethods.includes(requestMethod.toUpperCase())) {
                logger_1.logger.warn('OPTIONS request blocked: unsupported method', {
                    requestMethod,
                    allowedMethods: config.allowedMethods
                });
                return res.status(405).json({ error: 'Method not allowed' });
            }
        }
        // Set CORS headers
        res.header('Access-Control-Allow-Methods', config.allowedMethods.join(', '));
        res.header('Access-Control-Allow-Headers', config.allowedHeaders.join(', '));
        res.header('Access-Control-Expose-Headers', config.exposedHeaders.join(', '));
        res.header('Access-Control-Max-Age', config.maxAge.toString());
        if (config.credentials) {
            res.header('Access-Control-Allow-Credentials', 'true');
        }
        // Additional security headers for OPTIONS responses
        res.header('Vary', 'Origin, Access-Control-Request-Method, Access-Control-Request-Headers');
        res.header('Cache-Control', 'no-cache, no-store, must-revalidate');
        logger_1.logger.debug('OPTIONS preflight request handled successfully', {
            origin,
            requestMethod,
            path: req.path,
            maxAge: config.maxAge
        });
        // Return successful preflight response
        res.status(200).end();
    };
};
exports.createOptionsHandler = createOptionsHandler;
/**
 * Middleware to add CORS headers to all responses (not just OPTIONS)
 */
const addCorsHeaders = (config) => {
    return (req, res, next) => {
        const origin = req.get('Origin');
        // Add CORS headers to all responses if origin is allowed
        if (origin && config.allowedOrigins.includes(origin)) {
            res.header('Access-Control-Allow-Origin', origin);
            res.header('Access-Control-Expose-Headers', config.exposedHeaders.join(', '));
            if (config.credentials) {
                res.header('Access-Control-Allow-Credentials', 'true');
            }
        }
        next();
    };
};
exports.addCorsHeaders = addCorsHeaders;
/**
 * Comprehensive OPTIONS route handler for catch-all routes
 */
const handleAllOptions = (config) => {
    return (req, res) => {
        const origin = req.get('Origin');
        logger_1.logger.info('Handling catch-all OPTIONS request', {
            origin,
            path: req.path,
            method: req.method
        });
        // Set comprehensive CORS headers
        if (origin && config.allowedOrigins.includes(origin)) {
            res.header('Access-Control-Allow-Origin', origin);
        }
        res.header('Access-Control-Allow-Methods', config.allowedMethods.join(', '));
        res.header('Access-Control-Allow-Headers', config.allowedHeaders.join(', '));
        res.header('Access-Control-Expose-Headers', config.exposedHeaders.join(', '));
        res.header('Access-Control-Max-Age', config.maxAge.toString());
        if (config.credentials) {
            res.header('Access-Control-Allow-Credentials', 'true');
        }
        res.header('Vary', 'Origin');
        res.status(200).json({
            message: 'CORS preflight successful',
            allowedMethods: config.allowedMethods,
            allowedHeaders: config.allowedHeaders,
            maxAge: config.maxAge
        });
    };
};
exports.handleAllOptions = handleAllOptions;
//# sourceMappingURL=options-handler.js.map