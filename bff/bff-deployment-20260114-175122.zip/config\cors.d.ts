/**
 * Production-Only CORS Configuration Module
 *
 * Provides production-only CORS configuration with enhanced security.
 * Supports only production CloudFront origin for maximum security.
 */
import { CorsOptions } from 'cors';
import { OriginValidator } from '../security/origin-validator';
export interface CorsConfig {
    allowedOrigins: string[];
    corsOptions: CorsOptions;
    originValidator: OriginValidator;
}
/**
 * Initializes and returns production-only CORS configuration
 */
export declare const initializeCorsConfig: () => CorsConfig;
/**
 * Gets current CORS configuration for debugging/monitoring
 */
export declare const getCorsConfigInfo: () => {
    origins: string[];
    environment: string;
    securityLevel: string;
};
//# sourceMappingURL=cors.d.ts.map