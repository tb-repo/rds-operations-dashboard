/**
 * Enhanced Origin Validation and Security Module
 *
 * Provides comprehensive origin validation with security logging and threat detection.
 * Implements strict allowlist-based validation with detailed audit trails.
 */
export interface SecurityEvent {
    type: 'ORIGIN_BLOCKED' | 'INVALID_ORIGIN_FORMAT' | 'SUSPICIOUS_ORIGIN' | 'ORIGIN_ALLOWED';
    origin: string;
    reason: string;
    timestamp: Date;
    clientIp?: string;
    userAgent?: string;
    path?: string;
    method?: string;
}
export interface OriginValidationResult {
    allowed: boolean;
    reason: string;
    securityEvent?: SecurityEvent;
}
export declare class OriginValidator {
    private allowedOrigins;
    private securityEvents;
    private suspiciousPatterns;
    constructor(allowedOrigins: string[]);
    /**
     * Validates an origin against the allowlist with comprehensive security checks
     */
    validateOrigin(origin: string | undefined, clientIp?: string, userAgent?: string, path?: string, method?: string): OriginValidationResult;
    /**
     * Validates origin URL format and protocol
     */
    private isValidOriginFormat;
    /**
     * Detects suspicious patterns in origin
     */
    private detectSuspiciousPattern;
    /**
     * Logs security events with appropriate severity
     */
    private logSecurityEvent;
    /**
     * Gets recent security events for monitoring
     */
    getRecentSecurityEvents(limit?: number): SecurityEvent[];
    /**
     * Gets security statistics
     */
    getSecurityStats(): {
        totalEvents: number;
        blockedOrigins: number;
        suspiciousOrigins: number;
        invalidFormats: number;
        allowedOrigins: number;
    };
    /**
     * Updates the allowed origins list
     */
    updateAllowedOrigins(newOrigins: string[]): void;
}
//# sourceMappingURL=origin-validator.d.ts.map