"use strict";
/**
 * Lambda Handler for BFF using @vendia/serverless-express
 *
 * This file wraps the Express application for AWS Lambda execution.
 * It uses serverless-express to handle the conversion between Lambda events
 * and Express HTTP requests/responses.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const serverless_express_1 = __importDefault(require("@vendia/serverless-express"));
const index_1 = __importDefault(require("./index"));
// Create the serverless Express handler
// This will handle all Lambda invocations and route them to the Express app
exports.handler = (0, serverless_express_1.default)({ app: index_1.default });
//# sourceMappingURL=lambda.js.map