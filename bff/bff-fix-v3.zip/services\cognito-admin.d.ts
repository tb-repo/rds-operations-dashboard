export interface UserInfo {
    id: string;
    email: string;
    name?: string;
    groups: string[];
    status: string;
    createdAt: string;
    lastLogin?: string;
    attributes: Record<string, string>;
}
export interface ListUsersResult {
    users: UserInfo[];
    total: number;
    nextToken?: string;
}
export declare class CognitoAdminService {
    private client;
    private userPoolId;
    constructor(region: string, userPoolId: string);
    /**
     * List all users in the user pool
     */
    listUsers(limit?: number, paginationToken?: string): Promise<ListUsersResult>;
    /**
     * Get details for a specific user
     */
    getUserDetails(username: string): Promise<UserInfo | null>;
    /**
     * Get groups for a user
     */
    getUserGroups(username: string): Promise<string[]>;
    /**
     * Add user to a group (assign role)
     */
    addUserToGroup(username: string, groupName: string): Promise<boolean>;
    /**
     * Remove user from a group (revoke role)
     */
    removeUserFromGroup(username: string, groupName: string): Promise<boolean>;
    /**
     * Map Cognito user to UserInfo
     */
    private mapCognitoUser;
    /**
     * Get attribute value from Cognito attributes array
     */
    private getAttributeValue;
    /**
     * Map Cognito attributes to key-value object
     */
    private mapAttributes;
}
//# sourceMappingURL=cognito-admin.d.ts.map