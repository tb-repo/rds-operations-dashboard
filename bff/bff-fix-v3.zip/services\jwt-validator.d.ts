import { JwtPayload } from 'jsonwebtoken';
export interface CognitoTokenPayload extends JwtPayload {
    sub: string;
    email: string;
    email_verified: boolean;
    'cognito:groups'?: string[];
    'cognito:username': string;
    token_use: 'id' | 'access';
    auth_time: number;
}
export interface TokenValidationResult {
    valid: boolean;
    payload?: CognitoTokenPayload;
    error?: string;
}
export declare class JwtValidator {
    private jwksClient;
    private issuer;
    private audience?;
    private keyCache;
    private cacheExpiry;
    private readonly CACHE_TTL;
    constructor(userPoolId: string, region: string, clientId?: string);
    /**
     * Validate JWT token from Cognito
     */
    validateToken(token: string): Promise<TokenValidationResult>;
    /**
     * Get signing key from JWKS endpoint with caching
     */
    private getSigningKey;
    /**
     * Verify token signature using public key
     */
    private verifyTokenSignature;
    /**
     * Validate token claims
     */
    private validateClaims;
    /**
     * Check if token is expired
     */
    isTokenExpired(token: string): boolean;
    /**
     * Extract payload without verification (for debugging)
     */
    decodeToken(token: string): CognitoTokenPayload | null;
}
//# sourceMappingURL=jwt-validator.d.ts.map