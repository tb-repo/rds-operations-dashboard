import winston from 'winston';
export declare const logger: winston.Logger;
export default logger;
//# sourceMappingURL=logger.d.ts.map